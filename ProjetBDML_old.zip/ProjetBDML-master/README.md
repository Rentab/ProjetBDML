# ProjetBDML
Projet Big Data &amp; Machine Learning

// Remplacer la partie en write / read Scanner par un String split delimiter ""
